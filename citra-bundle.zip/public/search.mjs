const normalize = value => String(value || '').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9\s-]/g, ' ').replace(/\s+/g, ' ').trim();
const stop = new Set('tolong mohon kirim kirimkan tampilkan lihat melihat tunjukkan minta ingin saya mau ada apa seperti bagaimana contoh gambar foto photo image images pic picture yang dengan dari untuk dan di ke nya dong please show me the a of design desain citra bukit etam'.split(' '));
function words(query) {
  return normalize(query).replace(/master bedroom/g, 'kamar utama').replace(/living room/g, 'ruang tamu').replace(/kitchen/g, 'dapur').replace(/bedroom/g, 'kamar tidur').replace(/fasade|facade/g, 'fasad').replace(/floor plan/g, 'denah').replace(/nyata|asli|real/g, 'aktual').split(' ').filter(w => w && !stop.has(w));
}
export function searchAssets(catalog, options = {}) {
  const query = String(options.q || '').slice(0, 250);
  let kind = options.kind || '';
  if (!kind && /\b(foto|photo|aktual|asli|nyata)\b/i.test(query) && !/\b(desain|render|inspirasi|referensi)\b/i.test(query)) kind = 'photo_actual';
  const tokens = words(query);
  return catalog.assets.filter(a => (!kind || a.kind === kind) && (!options.category || a.category === options.category) && (!options.room || a.room === options.room) && (!options.id || a.id === options.id)).map(a => {
    const title = normalize(a.title), tags = normalize(a.tags.join(' ')), desc = normalize(a.description);
    const fields = `${title} ${tags} ${desc}`;
    if (tokens.some(token => !fields.includes(token))) return null;
    const score = tokens.reduce((n, token) => n + (title.includes(token) ? 8 : 0) + (tags.includes(token) ? 4 : 0) + (desc.includes(token) ? 1 : 0), 0);
    return { asset: a, score };
  }).filter(Boolean).sort((a, b) => b.score - a.score || b.asset.priority - a.asset.priority || a.asset.id.localeCompare(b.asset.id)).map(result => result.asset);
}
