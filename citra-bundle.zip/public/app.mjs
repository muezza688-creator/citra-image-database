import { searchAssets } from './search.mjs';
const catalog = window.CITRA_CATALOG;
const byId = id => document.getElementById(id);
let category = '';
const labels = catalog.categories;
const kinds = catalog.kinds;
const nav = byId('categories');
for (const [value, label] of [['', 'Semua gambar'], ...Object.entries(labels)]) {
  const button = document.createElement('button');
  button.textContent = label;
  button.setAttribute('aria-pressed', String(!value));
  button.onclick = () => { category = value; for (const sibling of nav.children) sibling.setAttribute('aria-pressed', String(sibling === button)); render(); };
  nav.append(button);
}
function openPreview(asset) {
  byId('preview-image').src = asset.image_path;
  byId('preview-image').alt = asset.alt_text;
  byId('preview-title').textContent = asset.title;
  byId('preview-label').textContent = kinds[asset.kind];
  byId('preview-note').textContent = asset.usage_note;
  const source = catalog.sources.find(s => s.id === asset.source_id);
  byId('preview-source').textContent = `Sumber: ${source.name}${asset.source_page ? ` · Halaman PDF ${asset.source_page}` : ''}${source.credit ? ` · ${source.credit}` : ''}`;
  byId('original').href = asset.image_path;
  byId('copied').textContent = '';
  byId('copy-url').onclick = async () => {
    const url = new URL(asset.image_path, window.location.href).href;
    try { await navigator.clipboard.writeText(url); byId('copied').textContent = 'URL gambar disalin.'; }
    catch { byId('copied').textContent = url; }
  };
  byId('preview').showModal();
}
function render() {
  const results = searchAssets(catalog, {q:byId('search').value, category, kind:byId('kind').value});
  byId('count').textContent = `${results.length} dari ${catalog.total_assets} gambar`;
  byId('empty').hidden = results.length > 0;
  const fragment = document.createDocumentFragment();
  for (const asset of results) {
    const article = document.createElement('article'); article.className = 'card';
    const button = document.createElement('button'); button.onclick = () => openPreview(asset);
    const photo = document.createElement('div'); photo.className = 'card-photo';
    const img = document.createElement('img'); img.src = asset.thumbnail_path; img.alt = asset.alt_text; img.loading = 'lazy'; img.width = 520; img.height = 347;
    const badge = document.createElement('span'); badge.className = 'badge'+(asset.kind==='photo_actual'?' actual':''); badge.textContent = kinds[asset.kind];
    photo.append(img,badge);
    const copy = document.createElement('div'); copy.className='card-copy';
    const label = document.createElement('span'); label.textContent=labels[asset.category];
    const h3 = document.createElement('h3'); h3.textContent=asset.title;
    const bottom = document.createElement('div'); bottom.className='card-bottom';
    const source=document.createElement('span'); source.textContent=asset.source_page?`PDF · Halaman ${asset.source_page}`:(asset.kind==='photo_actual'?'Foto dokumentasi':'Gambar unggahan');
    const view=document.createElement('span'); view.textContent='Lihat gambar ↗';
    bottom.append(source,view); copy.append(label,h3,bottom); button.append(photo,copy); article.append(button); fragment.append(article);
  }
  byId('grid').replaceChildren(fragment);
}
byId('search').addEventListener('input',render); byId('kind').addEventListener('change',render);
byId('close').onclick=()=>byId('preview').close();
byId('preview').addEventListener('click',e=>{if(e.target===byId('preview')){const r=byId('preview').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)byId('preview').close();}});
byId('catalog-url').textContent=new URL('data/catalog.json',window.location.href).href;
render();
