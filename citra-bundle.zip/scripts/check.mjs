import assert from 'node:assert/strict';
import { readFile, access } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import catalog from '../public/data/catalog.json' with { type: 'json' };
import handler from '../netlify/functions/images.mjs';

assert.equal(catalog.assets.length,65);
assert.equal(new Set(catalog.assets.map(a=>a.id)).size,65);
assert.equal(catalog.assets.filter(a=>a.kind==='photo_actual').length,2);
for(const a of catalog.assets){
  const bytes=await readFile(new URL('../public/'+a.image_path,import.meta.url));
  assert.equal(createHash('sha256').update(bytes).digest('hex'),a.sha256,a.id);
  assert.equal(bytes.length,a.bytes,a.id);
  await access(new URL('../public/'+a.thumbnail_path,import.meta.url));
  assert.ok(catalog.sources.some(s=>s.id===a.source_id));
}
async function query(params,method='GET'){
  const response=await handler(new Request('https://citra.example/api/images?'+params,{method}));
  return {response,data:method==='HEAD'||response.status===204?null:await response.json()};
}
let r=await query('kind=photo_actual&limit=30');assert.equal(r.data.total,2);assert.ok(r.data.results.every(a=>a.image_url.startsWith('https://citra.example/images/')));
r=await query('q=foto%20rumah%20malam');assert.equal(r.data.total,1);assert.equal(r.data.results[0].id,'citra-aktual-fasad-malam');
r=await query('q=foto%20kamar%20anak');assert.equal(r.data.total,0);
r=await query('room=kamar-anak&kind=design_render');assert.equal(r.data.total,1);assert.equal(r.data.results[0].source_page,21);
r=await query('q=alien-zebra');assert.equal(r.data.total,0);
r=await query('limit=30&page=3');assert.equal(r.data.results.length,5);assert.equal(r.data.has_more,false);
r=await query('q=site%20plan');assert.ok(r.data.total>=1);assert.equal(r.data.results[0].id,'citra-site-plan-kavling');
r=await query('id=citra-site-plan-kavling');assert.equal(r.data.total,1);assert.equal(r.data.results[0].kind,'floor_plan');assert.match(r.data.results[0].usage_note,/bukan konfirmasi stok terkini/);
for(const params of ['limit=0','limit=31','limit=abc','page=0','kind=invalid','category=invalid','room=invalid'])assert.equal((await query(params)).response.status,400,params);
assert.equal((await query('', 'POST')).response.status,405);
assert.equal((await query('', 'OPTIONS')).response.status,204);
assert.equal((await query('', 'HEAD')).response.status,200);
assert.equal((await query('')).response.headers.get('access-control-allow-origin'),'*');
console.log('LULUS: 65 aset, file dan hash cocok; pencarian site plan/aktual/interior, hasil kosong, pagination, filter, CORS dan metode HTTP.');
