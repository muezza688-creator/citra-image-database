import http from 'node:http';
import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import handler from '../netlify/functions/images.mjs';
const root=path.resolve(fileURLToPath(new URL('../public/',import.meta.url)));
const types={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.mjs':'text/javascript','.json':'application/json','.jpg':'image/jpeg','.md':'text/plain; charset=utf-8'};
const server=http.createServer(async(req,res)=>{
  try{
    const url=new URL(req.url,'http://localhost:4173');
    if(url.pathname==='/api/images'){
      const result=await handler(new Request(url,{method:req.method}));
      res.writeHead(result.status,Object.fromEntries(result.headers));res.end(await result.text());return;
    }
    const file=path.resolve(root,'.'+decodeURIComponent(url.pathname==='/'?'/index.html':url.pathname));
    if(file!==root&&!file.startsWith(root+path.sep)){res.writeHead(403);res.end();return;}
    const data=await readFile(file);res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Access-Control-Allow-Origin':'*'});res.end(data);
  }catch{res.writeHead(404);res.end('Tidak ditemukan');}
});
server.listen(4173,'127.0.0.1',()=>console.log('Pratinjau http://localhost:4173'));
