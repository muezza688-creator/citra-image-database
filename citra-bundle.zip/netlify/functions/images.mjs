import catalog from '../../public/data/catalog.json' with { type: 'json' };
import { searchAssets } from '../../public/search.mjs';

const headers = {
  'Content-Type': 'application/json; charset=utf-8',
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, HEAD, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Cache-Control': 'public, max-age=300',
  'X-Content-Type-Options': 'nosniff'
};
const json = (body, status = 200, extra = {}) => new Response(JSON.stringify(body), { status, headers: { ...headers, ...extra } });

export default async function handler(request) {
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
  if (!['GET', 'HEAD'].includes(request.method)) return json({ error: 'Gunakan GET untuk membaca katalog gambar.' }, 405, { Allow: 'GET, HEAD, OPTIONS' });
  const url = new URL(request.url), p = url.searchParams;
  const kind = p.get('kind') || '', category = p.get('category') || '', room = p.get('room') || '';
  const q = p.get('q') || p.get('query') || '';
  if (q.length > 250) return json({ error: 'Pencarian maksimal 250 karakter.' }, 400);
  if (kind && !Object.hasOwn(catalog.kinds, kind)) return json({ error: 'kind tidak dikenal', allowed: Object.keys(catalog.kinds) }, 400);
  if (category && !Object.hasOwn(catalog.categories, category)) return json({ error: 'category tidak dikenal', allowed: Object.keys(catalog.categories) }, 400);
  const rooms = [...new Set(catalog.assets.map(a => a.room))];
  if (room && !rooms.includes(room)) return json({ error: 'room tidak dikenal', allowed: rooms }, 400);
  const positiveInt = (key, fallback, max) => {
    const value = p.get(key);
    if (value === null) return fallback;
    if (!/^\d+$/.test(value) || Number(value) < 1 || Number(value) > max) return null;
    return Number(value);
  };
  const limit = positiveInt('limit', 6, 30), page = positiveInt('page', 1, 10000);
  if (limit === null || page === null) return json({ error: 'limit harus 1–30 dan page harus 1–10000.' }, 400);
  const matches = searchAssets(catalog, { q, kind, category, room, id: p.get('id') || '' });
  const results = matches.slice((page - 1) * limit, page * limit).map(a => ({
    ...a,
    image_url: new URL(a.image_path, url.origin + '/').href,
    thumbnail_url: new URL(a.thumbnail_path, url.origin + '/').href,
    source: catalog.sources.find(source => source.id === a.source_id)
  }));
  const body = { project: catalog.project_name, query: q, total: matches.length, page, limit, has_more: page * limit < matches.length, results };
  if (!matches.length) body.message = 'Tidak ada gambar yang cocok. Jangan mengganti dengan gambar yang tidak sesuai; tawarkan kategori lain.';
  return request.method === 'HEAD' ? new Response(null, { status: 200, headers }) : json(body);
}

export const config = { path: '/api/images' };
